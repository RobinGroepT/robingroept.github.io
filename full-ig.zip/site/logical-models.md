Logical Models Overview

The Logical Models provide a functional foundation for these specifications. 

The following Logical Data Models are defined in this specification:

* Patient
* Practitioner
* PractitionerRole
* Communication
* AllergyIntolerance
* KMEHR Document
* Immunization